var mysql = require('mysql');
var config = require('./config.json');
var connection  = mysql.createConnection({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false

    // Use the connection
    connection.query(`SELECT * FROM career_center.events WHERE MONTH(date) = ${event.query.month};`, function (error, results, fields) {
      // Handle error after the release.
      if (error) callback(error);
      callback(null, {
	  	statusCode: 200,
		  body: results}) 
    });
};


