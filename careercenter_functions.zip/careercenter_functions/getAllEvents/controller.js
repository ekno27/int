module.exports = {
	createEvent(event) {
		let body = JSON.parse(event.body)
	    console.log('this was the cart: ', body)
	    return {
	        statusCode: 200, 
	        body: JSON.stringify({
	            message: 'item was succesfully added'
	        })
	    }
    },
    
    editEvent(event) {
    	
    },
    
    deleteEvent(event) {
    	
    },
	
	getEventsPerMonth(event) {
		const totalEvents = {
       		totalEvents:  [
				//this will be populated from server
			
				{
					event: "Resu-Makeover",
					month: "October",
					day: 10,
					year: 2019,
					
					image: 'isk'
				},
				{
					event: "Matty's Boo Boo",
					month: "October",
					day: 21,
					year: 2019,
					image: 'idk'
				}
			]
       }
       return {
	  	statusCode: 200,
		body: JSON.stringify(totalEvents)
		}
		
	},
	
    getAllEvents() {
       const totalEvents = {
       		totalEvents:  [
				//this will be populated from server
				{
					event: "Tech Fest",
					month: "February",
					day: 13,
					year: 2019,
					image: "fhjf"
				},
				{
					event: "Resu-Makeover",
					month: "October",
					day: 10,
					year: 2019,
					
					image: 'isk'
				},
				{
					event: "Matty's Boo Boo",
					month: "October",
					day: 21,
					year: 2019,
					image: 'idk'
				}
			]
       }
	  return {
	  	statusCode: 200,
		body: JSON.stringify(totalEvents)
		}
    },
    
}