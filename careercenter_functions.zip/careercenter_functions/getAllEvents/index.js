const controller = require('./controller')
exports.handler = async (event, context, callback) => {
    
    console.log(context)
    const path = event.path
    const method = event.httpMethod
    console.log(path)
    // TODO implement
    if(method =='GET' && path =='/events/all' ) {
        return controller.getAllEvents();
    }
    if (method == 'POST' && path == '/events') {
        return controller.createEvent(event)
    }
    if (method == 'DELETE' && path.includes('/events')) {
        return controller.deleteEvent(event)
    }
    if(method == 'GET' && path.includes('/events')) {
        return controller.getEventsPerMonth(event)
    }
    if(method == 'PUT' && path.includes('/events')) {
        return controller.editEvent(event)
    }
};

