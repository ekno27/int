var mysql = require('mysql');
var config = require('./config.json');
var connection  = mysql.createConnection({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
    // Use the connection
    console.log(event.query.idevents);
    connection.query(`DELETE FROM career_center.events WHERE (idevents = ${event.query.idevents})`, function (error, results, fields) {
      // Handle error after the release.
      if (error) {
       callback(error);
      }
      else {
        callback(null, {
	  	  statusCode: 201,
		    body: `Event with id ${event.query.idevents} has been succesfully deleted`});
      }
    });
};