var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

pool.getConnection(function(err, connection) {
  // Use the connection
  var event = {
    body: {
      "name": "Happy nappy",
      // "description": "Sleepy treepr"
      "date": "2018-10-03 17:00:00",
      // "location": "Bayramian Hall 1324",
      // "price": "$12",
      "handshake_link": "https://www.google.com/",
      // "website_link": "https://www.youtube.com/"
    },
    query: {
      idevents: '2'
    }
  }
  mysqlQuery = `UPDATE career_center.events SET `;

  for (var column in event.body) {
    mysqlQuery += `${column} = '${event.body[column]}', `;
  }
  mysqlQuery = mysqlQuery.substring(0, mysqlQuery.length - 2);
  mysqlQuery = mysqlQuery + ` WHERE (idevents = ${event.query.idevents})`

  // connection.query(`UPDATE career_center'.'events' SET 'description' = 'meme', 'date' = 'q' WHERE ('idevents' = '3')`, function (error, results, fields) {
  connection.query(mysqlQuery, function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) throw error;
    else console.log(results);
    process.exit();
  });
})