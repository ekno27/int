var mysql = require('mysql');
var config = require('./config.json');
var connection  = mysql.createConnection({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  var mysqlQuery = `UPDATE career_center.events SET `;
  
  for (var column in event.body) {
    mysqlQuery += `${column} = '${event.body[column]}', `;
  }
  mysqlQuery = mysqlQuery.substring(0, mysqlQuery.length - 2);
  mysqlQuery = mysqlQuery + ` WHERE (idevents = ${event.query.idevents})`;
  
  connection.query(mysqlQuery, function (error, results, fields){
    // Handle error after the release.
    if (error) callback(error);
    callback(null, {
	  statusCode: 200,
		body: `Event with id ${event.query.idevents} has been succesfully updated`}) 
  });
};