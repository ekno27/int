var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

pool.getConnection(function(err, connection) {
    var event = {
        name: "Career center", 
        description: 'Find a job here uwu', 
        date: '2018-03-03 17:00:00',
        location: "bayramian uwu",
        price: '$12', 
        handshake_link: 'http://www.google.com',
        website_link: 'http://www.google.com'

    }
  // Use the connection
  connection.query(`INSERT INTO events (name, description, date, location, price, handshake_link, website_link) VALUES ('${event.name}', '${event.description}', '${event.date}', '${event.location}', '${event.price}', '${event.handshake_link}', '${event.website_link}')`, function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) throw error;
    else console.log(results);
    process.exit();
  });
})
