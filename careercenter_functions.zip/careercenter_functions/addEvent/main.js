var mysql = require('mysql');
var config = require('./config.json');
var connection  = mysql.createConnection({
    host     : config.dbhost,
    user     : config.dbuser,
    password : config.dbpassword,
    database : config.dbname
  });

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false
  
    // Use the connection
    connection.query(`INSERT INTO events (name, description, date, location, price, handshake_link, website_link) VALUES ('${event.body.name}', '${event.body.description}', '${event.body.date}', '${event.body.location}', '${event.body.price}', '${event.body.handshake_link}', '${event.body.website_link}')`, function (error, results, fields) {
      // Handle error after the release.
      if (error) callback(error);
      callback(null, {
	  	statusCode: 201,
		  body: "Event has been successfully added"}) 
    });
};