const AWS = require('aws-sdk');
const BUCKET_NAME = 'career-center-event-images';
const s3 = new AWS.S3();
AWS.config.region = 'us-west-2';


exports.handler = async (event, context, callback) => {
    console.log('help');
    let encodedData = "c2FtcGxlIHRleHQ=";
    let fileContent = Buffer.from(encodedData, 'base64');
    const params = {
        Bucket: BUCKET_NAME,
        Key: 'test.txt',
        Body: fileContent
    };
    // console.log(s3)
    s3.upload(params, function(err, data){
        console.log('uploading');
        if(err){
            console.log('error')
            callback('undefined error', err);
        }
        // console.log('nic');
        callback('undefinded error',  `it's all good my guy: ${data.location}`)
    })
};


// let encodedData = 'SGVsbG8g8J+Yig==';
// let buff = Buffer.from(encodedData, 'base64'); 

// fs.writeFile('my-file.png', buff, (err) => {
//   if (err) throw err;
//   console.log('The binary data has been decoded and saved to my-file.png');
// });